function [Vm] = getVm(H,dm)
%GETVM Summary of this function goes here
%   Detailed explanation goes here
x=H/dm;
Vm=0.0003;
end

