function [b] = find_gear_width(r_gear)
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
%b=11.5/P; %width in inches
b=(1/4)*r_gear;
end

