function [gr] = find_gr(num_gears)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

gr=1.67/num_gears;

end

