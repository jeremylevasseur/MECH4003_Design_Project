function [N] = find_num_teeth(P,r_gear)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
%i think r_gear is ptch radius

N=2*P*r_gear;

end

